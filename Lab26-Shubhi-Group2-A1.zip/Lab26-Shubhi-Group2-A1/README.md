# Lab26-Shubhi-Group2-A1

How to use:

1. Start the program by first building it with Gradle with the command:
`gradle build`

2. Then run the program using Gradle with the command:
`gradle run`

3. 
